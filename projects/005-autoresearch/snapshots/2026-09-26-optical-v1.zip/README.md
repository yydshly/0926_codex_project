# GitHub 优秀项目研究集

这是优秀 GitHub 仓库的研究索引。每个子项目记录原项目的能力、技术原理、来源、已核对的发现与验证边界；可交互的成果在适合时提供独立网页。

> 这里是摘要与导航。完整研究内容放在各子项目目录中。所有原项目的代码、图片和名称仍归其作者及贡献者所有；引用和再使用请遵守对应项目的许可证。

## 项目索引

子项目按编号展示，编号一经使用不因新增项目而重排。

| 编号 | 子项目与原仓库 | 能力摘要 | 阅读入口 |
| --- | --- | --- | --- |
| 001 | [Chat2DB](projects/001-chat2db/README.md) · [原仓库](https://github.com/OtterMind/Chat2DB) | 数据库工作台；AI 依据表结构辅助写 SQL，结果由数据库执行。 | [研究记录](projects/001-chat2db/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/001-chat2db/) |
| 002 | [Browser Use Web UI](projects/002-browser-use-web-ui/README.md) · [原仓库](https://github.com/browser-use/web-ui) | 配置、运行并观察浏览器代理，展示读取、决策、执行与核对循环。 | [研究记录](projects/002-browser-use-web-ui/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/002-browser-use-web-ui/) |
| 003 | [Antra](projects/003-antra/README.md) · [原仓库](https://github.com/anandprtp/Antra) | 匹配多来源音源，下载、校验、打标并整理本地曲库。 | [研究记录](projects/003-antra/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/003-antra/) |
| 004 | [StemDeck](projects/004-stemdeck/README.md) · [原仓库](https://github.com/stemdeckapp/stemdeck) | Demucs 估计六类音轨，支持试听、循环练习、混音与导出。 | [研究记录](projects/004-stemdeck/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/004-stemdeck/) |
| 005 | [Autoresearch](projects/005-autoresearch/README.md) · [原仓库](https://github.com/karpathy/autoresearch) | 代理通过固定评测迭代训练方案，保留有效改进。 | [研究记录](projects/005-autoresearch/README.md) · [本地交互仿真](sites/005-autoresearch/index.html)（未发布） |
| 006 | [vercel/eve](projects/006-vercel-eve/README.md) · [原仓库](https://github.com/vercel/eve) | 持久会话、工具调用与人工审批构成 Agent 服务。 | [研究记录](projects/006-vercel-eve/README.md) · [本地交互演示](sites/006-vercel-eve/index.html)（未发布） |

新增项目时按编号添加索引行。项目名链接到对应的 `projects/NNN-项目名/README.md`；有本地展示页时在最后一列添加对应链接。每个子项目的封面图和截图放在自己的 `assets/` 目录，并在子项目 README 中标明来源。

## 子项目速览

### 001 · Chat2DB

<img src="projects/001-chat2db/assets/architecture-map.png" width="460" alt="Chat2DB 能力与语义关联总图：入口、内部模块、模型与数据库、业务定义及输出">

图片说明：本仓库绘制的 Chat2DB 能力与原理引导图，依据[原仓库](https://github.com/OtterMind/Chat2DB)和已核对源码整理；是分析示意，不是官方架构图或运行截图。[放大查看 SVG](projects/001-chat2db/assets/architecture-map.svg)。

- **能力：** Chat2DB 是本机优先的数据库客户端和 SQL 工作台，可连接多种数据库、浏览结构、编辑和执行 SQL、管理数据、导入导出、查看图表；接入自选模型后可用自然语言生成、解释和优化 SQL。
- **原理与模块：** 交互界面把所选数据源、真实表结构与可提供的业务说明交给 AI 编排层；元数据工具辅助模型起草 SQL，数据库连接与执行模块取得真实结果，最后由结果和可视化模块展示。独立 CLI/MCP 可供脚本与 Agent 使用。
- **入口与出口：** 入口有人提出的问题、手写 SQL、表操作及 CLI/MCP 调用；出口包括 SQL 草稿、真实查询结果、图表与数据管理操作。
- **场景与意义：** 适合开发排查、DBA 管理、临时分析和受控 Agent 查询；它提供了研究或构建自然语言数据助手的完整样本。
- **边界：** “销售额”“退款”等复杂指标必须明确统计口径。字段注释与模型推断不能自动证明业务答案正确；本研究尚未安装 Chat2DB 连接真实数据库。[详细研究与源码证据](projects/001-chat2db/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/001-chat2db/)。

### 002 · Browser Use Web UI

<img src="projects/002-browser-use-web-ui/assets/understanding-map.png" width="460" alt="Browser Use Web UI 能力与价值总览：界面、代理、模型与浏览器的分工">

图片说明：本仓库依据[原仓库文档与源码](https://github.com/browser-use/web-ui)绘制的理解汇总图，不是原产品运行截图或真实任务结果。[放大查看 SVG](projects/002-browser-use-web-ui/assets/understanding-map.svg)。

- **能力与原理：** Web UI 负责任务入口、设置、过程展示与控制；`browser-use` 和浏览器控制层负责网页操作。
- **模块效果：** 模型与浏览器设置决定运行条件，Run Agent 展示步骤，Deep Research 汇总资料，配置与工具扩展便于复用。
- **研究价值：** 可探索带来源证据和人工验收的资料收集流程。[研究记录](projects/002-browser-use-web-ui/README.md) · [在线展示](https://yydshly.github.io/0926_codex_project/sites/002-browser-use-web-ui/)。

### 003 · Antra

<img src="sites/003-antra/assets/capability-map.png" width="460" alt="Antra 完整能力地图：多类入口、统一曲目、音源匹配、下载校验、打标归档、本地出口与研究价值">

图片说明：本研究依据[Antra 官方功能说明](https://github.com/anandprtp/Antra/blob/07aeef19966d8e2b72ed53f53442596e8a53255c/FEATURES.md)和关键源码绘制的能力总图；是研究引导图，不是官方架构图或实测结果。[放大查看 SVG](sites/003-antra/assets/capability-map.svg)。

- **能力与原理：** 从链接或已连接的在线曲库提取曲目，统一标题、艺人、ISRC 等信息；适配器寻找音源，解析器匹配录音，下载引擎校验后打标归档。
- **模块与出口：** 桌面界面、链接解析、统一曲目、音源解析、下载校验、标签与曲库、同步与历史、播放器与分析器；输出本地音频文件和可浏览的曲库。
- **场景与意义：** 适合经授权建立个人曲库、维护更新歌单；提供研究多源数据一致化、身份匹配与交付校验的完整案例。
- **边界：** 本研究尚未进行真实下载；音源可用性、文件质量、内容权限与标签完整度需核查。[研究记录](projects/003-antra/README.md) · [在线能力展示](https://yydshly.github.io/0926_codex_project/sites/003-antra/)。

### 004 · StemDeck

<img src="projects/004-stemdeck/assets/capability-map.png" width="460" alt="StemDeck 能力引导图：六类音源估计、练习与创作模块及适用场景">

图片说明：本仓库依据[StemDeck 原仓库](https://github.com/stemdeckapp/stemdeck)和 Demucs 资料绘制的研究引导图；展示六轨分离及后续工作流，不代表分离音质实测。[放大查看 SVG](projects/004-stemdeck/assets/capability-map.svg)。

研究重点是 Demucs 分离模型如何与本地音频处理、多轨交互和练习场景组成完整产品。[查看研究记录](projects/004-stemdeck/README.md) · [打开在线能力展示](https://yydshly.github.io/0926_codex_project/sites/004-stemdeck/)

### 005 · Autoresearch

<img src="projects/005-autoresearch/assets/official-progress.png" width="460" alt="Autoresearch 上游实验进展图：83 次实验中的改进与未保留结果">

图片说明：来自[Autoresearch 原仓库的真实实验进展图](https://github.com/karpathy/autoresearch/blob/master/progress.png)，展示上游 83 次实验与 15 次保留改进；不是本项目无人机仿真结果。图片来源和使用说明见[研究记录](projects/005-autoresearch/README.md)。

研究重点是理解“修改、固定评测、保留或回退”的自动实验循环，并用三维无人机与固定光学站点展示发现、跟踪、判断、定向标记的过程。[查看研究记录](projects/005-autoresearch/README.md) · [打开本地交互仿真](sites/005-autoresearch/index.html)

### 006 · vercel/eve

<img src="projects/006-vercel-eve/assets/cover.svg" width="460" alt="eve Agent 工作流程示意：请求进入持久会话，经工具调用与人工审批后继续">

图片说明：本仓库原创绘制的 eve 工作流程示意图，展示入口、会话、模型与工具、人工审批；不是运行截图，未使用第三方素材。

研究重点是弄清多步 Agent 的执行与恢复机制；仓库研究筛选示例已构建并验证真实 GitHub 查询，完整模型与审批流程仍待验证。[查看能力全景图](projects/006-vercel-eve/assets/eve-capability-map.svg) · [查看研究记录](projects/006-vercel-eve/README.md) · [打开本地交互演示](sites/006-vercel-eve/index.html)

## 仓库结构

```text
.
├─ README.md                    # 总览与有序索引
├─ projects/                    # 按 001、002、003… 编号的研究子项目
├─ sites/                       # 可选的静态网页展示
└─ templates/subproject/        # 新研究项目的起始模板
```

## 阅读与新增

从上方索引按顺序进入子项目。每份研究记录包含原仓库链接、研究动机、重点发现、验证过程、图片说明和许可信息。新增项目时，复制 [`templates/subproject/`](templates/subproject/README.md) 到 `projects/` 下的新编号目录，填写内容后在本页索引增加一行。

若有网页展示，建议放在 `sites/同编号同名称/`，并在索引和子项目 README 中链接。001 · Chat2DB、002 · Browser Use Web UI、003 · Antra 与 004 · StemDeck 已通过 GitHub Pages 发布；其余网页目前仍是本地草稿。

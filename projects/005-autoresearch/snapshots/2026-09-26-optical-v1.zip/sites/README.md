# 网页展示

这里预留给子项目的独立静态网页。一个子项目对应一个与研究目录同名的子目录，例如：

```text
projects/001-example/README.md
sites/001-example/index.html
```

网页应使用相对路径引用自身资源，便于日后统一发布到 GitHub Pages 的子路径。网页首页提供返回总项目索引的入口；总 README 和子项目 README 则链接到相应展示页。

## 本地展示

- [001 · Chat2DB 能力解释](https://yydshly.github.io/0926_codex_project/sites/001-chat2db/)：已发布；用模拟订单说明数据库、客户端与 AI 助手的分工。[本地源码](001-chat2db/index.html)。
- [002 · Browser Use Web UI 能力解释](https://yydshly.github.io/0926_codex_project/sites/002-browser-use-web-ui/)：已发布；用研究汇总图与虚构网页任务解释代理循环、模块效果和研究价值。[本地源码](002-browser-use-web-ui/index.html)。
- [003 · Antra 完整能力地图](https://yydshly.github.io/0926_codex_project/sites/003-antra/)：已发布；一图汇总入口、内部模块、出口、使用效果与研究价值，并用静态交互解释音乐链接到本地曲库的流程。[本地源码](003-antra/index.html)。
- [004 · StemDeck 能力展示](https://yydshly.github.io/0926_codex_project/sites/004-stemdeck/)：以原创能力引导图汇总六轨分离、效果、原理、场景与音频创作产品价值；[本地源码](004-stemdeck/index.html)不处理真实音频。
- [005 · Autoresearch 研究与仿真](005-autoresearch/index.html)：解释自动实验循环，用三维无人机与固定光学站点展示发现、跟踪、判断和定向标记，并运行 24 次配对观察实验；尚未发布。
- [006 · eve Agent 服务能力演示](006-vercel-eve/index.html)：实时读取公开 GitHub 仓库信息，用清楚标注的浏览器模拟展示建议、审批和下一轮读回；不运行 eve 或模型，尚未发布。

001 · Chat2DB、002 · Browser Use Web UI、003 · Antra 与 004 · StemDeck 已通过 GitHub Pages 发布。其他条目目前仍是本地草稿。
